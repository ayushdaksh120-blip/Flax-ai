const OPENAI_BASE = 'https://co.agentrouter.org/v1';
const ANTHROPIC_BASE = 'https://co.agentrouter.org';

export async function agentRouterService({ model, messages, temperature = 0.7, maxTokens = 2048 }) {
  const key = process.env.AGENTROUTER_API_KEY;
  if (!key) {
    const error = new Error('AI is not configured yet. Add AGENTROUTER_API_KEY in the Secrets tab.');
    error.status = 503;
    throw error;
  }
  const safeMessages = messages.map(({ role, content }) => ({ role, content: String(content).slice(0, 30000) }));
  let response;
  if (model.protocol === 'anthropic') {
    const system = safeMessages.filter(m => m.role === 'system').map(m => m.content).join('\n');
    const conversation = safeMessages.filter(m => m.role !== 'system').map(m => ({ role: m.role, content: m.content }));
    response = await fetch(`${ANTHROPIC_BASE}/v1/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: model.model_id, max_tokens: maxTokens, temperature, ...(system ? { system } : {}), messages: conversation }),
      signal: AbortSignal.timeout(90000),
    });
  } else if (model.protocol === 'openai') {
    response = await fetch(`${OPENAI_BASE}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: model.model_id, messages: safeMessages }),
      signal: AbortSignal.timeout(90000),
    });
  } else {
    throw new Error('Unsupported model protocol');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error('AgentRouter request failed with status:', response.status);
    const error = new Error(response.status === 429 ? 'The AI service is busy. Please try again shortly.' : 'The selected model could not respond. Check its configuration or try another model.');
    error.status = response.status === 429 ? 429 : 502;
    throw error;
  }
  const content = model.protocol === 'anthropic'
    ? data.content?.filter(block => block.type === 'text').map(block => block.text).join('\n')
    : data.choices?.[0]?.message?.content;
  if (!content || typeof content !== 'string') throw new Error('The model returned an empty response.');
  return { content, usage: data.usage ?? null };
}
