# FLAX AI

**One place for every AI.** A responsive multi-model AI chat workspace built with React, TypeScript, Vite, Vercel Functions, and Supabase Postgres.

## Architecture

```
User → React frontend → FLAX AI backend (/api/chat) → AgentRouter → selected model
User ← React frontend ← FLAX AI backend ← AgentRouter ← selected model
```

AgentRouter is the **only AI gateway**. The browser never talks to AgentRouter or a model provider. The only endpoint for sending an AI prompt is `POST /api/chat`; other `/api/*` routes handle conversations, catalog, profile and administration. The AgentRouter secret is read only inside the server-side `api/agentRouterService.js`.

- **OpenAI-compatible models** (GPT, DeepSeek): `POST https://co.agentrouter.org/v1/chat/completions`, Bearer authentication.
- **Claude models**: `POST https://co.agentrouter.org/v1/messages`, Anthropic Messages payload and `x-api-key` / `anthropic-version` headers. Protocols are kept separate and selected from the trusted server-side model record, never from an arbitrary client URL.

## Features

- Premium landing page, light/dark themes, mobile navigation and responsive chat workspace.
- Email/password auth, Google OAuth popup support, private conversations, searchable history, rename/delete, model selector, markdown/GFM and copyable code blocks.
- Loading skeletons, empty states, validation, error feedback and toast notifications.
- Admin-only model library with create, edit, activation, deletion, ordering, protocol and metadata configuration.
- Supabase/Postgres persistence and server-side ownership checks on every private resource.

## Requirements

Node.js 20+, a Supabase project, a Vercel deployment and an AgentRouter account/key. The starter catalog contains example model IDs: **check and adjust IDs against the models enabled in your AgentRouter account** in the admin console before sending requests. Model availability and naming vary by account.

## Configuration

The deployment already supplies `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` for the backend. Configure equivalent values for your own deployment. Do not commit secrets.

| Variable | Where | Purpose |
| --- | --- | --- |
| `AGENTROUTER_API_KEY` | **Server-only Vercel secret** | Authenticates upstream AI calls; required to send messages |
| `NEXT_PUBLIC_SUPABASE_URL` | Backend environment | Supabase URL used by server-side DB client |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Backend environment | Public key for Supabase auth operations |
| `SUPABASE_SERVICE_ROLE_KEY` | **Server-only** | Privileged DB access, never exposed to client |
| `VITE_SUPABASE_URL` | Frontend build | Public Supabase URL for user authentication |
| `VITE_SUPABASE_ANON_KEY` | Frontend build | Public anon key for user authentication |
| `VITE_GOOGLE_CLIENT_ID` | Frontend build, optional | Google OAuth client ID |
| `VITE_GOOGLE_AUTH_PROXY` | Frontend build, optional | OAuth proxy redirect URI |

**Before chatting, add `AGENTROUTER_API_KEY` in the Secrets tab.** It is not configured by default. The UI still works without it; chat returns a clear configuration error. Never prefix this secret with `VITE_`, put it in frontend code, save it in Postgres, or send it from the browser. Google auth requires its optional OAuth variables and the provider enabled in Supabase; email/password works independently.

## Local setup

1. Install dependencies: `npm install`.
2. Set the environment variables above in your local environment. Vite needs the two `VITE_SUPABASE_*` public variables at build time. For local serverless API testing, use `vercel dev` with the backend variables configured; `vite` alone serves the frontend and does not run `/api` functions.
3. Start with `vercel dev` (or deploy to Vercel). Run `npm run build` to check TypeScript and bundle output.
4. Create an account, log in, select a model and start a conversation.

## Database schema

- `profiles`: `user_id` (auth user UUID stored as text, PK), `display_name`, `role` (`USER` or `ADMIN`), `created_at`.
- `models`: integer PK, `display_name`, `model_id` (upstream identifier), `provider`, `protocol` (`openai` or `anthropic`), `description`, `badge`, `context_window`, `is_active`, `is_featured`, `sort_order`, `accent`, `created_at`.
- `conversations`: integer PK, `user_id`, `title`, `model_id` (FK → `models.id`), `created_at`, `updated_at`.
- `messages`: integer PK, `conversation_id` (FK → `conversations.id`), `user_id`, `role`, `content`, `created_at`.

Auth identities are managed by Supabase Auth. User data is isolated by server-side token verification and ownership filters; RLS policies add another layer. The service role bypasses RLS, which is why every privileged route explicitly verifies the user and scopes each query. Never let clients control the role field. New accounts default to `USER`; promote a trusted account to `ADMIN` by updating its `profiles.role` with a secure database administrator operation, never through a public API. The seeded demo administrator is for preview/testing only: change its password or remove it before a real production launch.

## API

- `GET /api/models`: public active catalog (no provider credentials).
- `GET /api/profile`, `PUT /api/profile`: authenticated profile.
- `GET /api/conversations`: user's threads. `GET /api/conversations?id=N`: thread with messages.
- `POST /api/conversations`, `PUT /api/conversations`, `DELETE /api/conversations`: authenticated thread CRUD.
- `POST /api/chat`: authenticated AI request with `{ content, model_id, conversation_id? }`. Fetches trusted model config and owned history, routes to AgentRouter, persists reply, returns messages.
- `GET/POST/PUT/DELETE /api/admin-models`: ADMIN-only catalog management.

API requests except the public model catalog need a Supabase access token in `Authorization: Bearer <token>`. Chat prompts are limited to 12,000 characters and context to the 30 most recent messages. Upstream timeouts and errors are handled without exposing credentials or raw provider responses.

## Security & production notes

All AI keys remain server-side. Admin privilege is checked using an authenticated user ID and trusted profile row. Private resources are scoped by user ID even when the service-role DB client is used. User content is rendered through React Markdown rather than injected as HTML; outbound links use `noopener noreferrer`. To scale further, add per-user rate limits, abuse monitoring, transactional message persistence and streaming responses through the backend. Review retention, privacy, billing limits, allowed origins, and model IDs for your own production environment.
